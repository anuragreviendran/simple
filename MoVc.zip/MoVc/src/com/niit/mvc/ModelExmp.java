package com.niit.mvc;

public class ModelExmp {
	private String uid,upd;
	public boolean accept(String id, String ps)
	{
	uid=id;
	upd=ps;
	
	if(uid.equals("aa")&& upd.equals("123"))
	{
		return true;
		
	}
	else
	{
		return false;
	}
	
	}
	 
	

}
